const http = require('http');
const crypto = require('crypto');
const { WebSocketServer, WebSocket } = require('ws');
const { spawn } = require('child_process');
const URL = require('url');

const PORT = Number(process.env.PORT || 3000);
const TOKEN = process.env.STUDIO_API_TOKEN || '';
const TURN_SECRET = process.env.TURN_SECRET || '';
const DOMAIN = process.env.APP_DOMAIN || 'localhost';
const rooms = new Map();
const broadcasts = new Map();

function send(ws, data) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); }
function json(res, code, data) { res.writeHead(code, {'content-type':'application/json','access-control-allow-origin':'*','access-control-allow-headers':'content-type,authorization','access-control-allow-methods':'GET,POST,OPTIONS'});res.end(JSON.stringify(data));}
function authorized(req) { return TOKEN && req.headers.authorization === `Bearer ${TOKEN}`; }
function cleanRoom(s) { return String(s || '').toLowerCase().replace(/[^a-z0-9_-]/g,'-').slice(0,32); }

const server = http.createServer((req,res)=>{
 const parsed=URL.parse(req.url,true);
 if(req.method==='OPTIONS'){res.writeHead(204,{'access-control-allow-origin':'*','access-control-allow-headers':'content-type,authorization','access-control-allow-methods':'GET,POST,OPTIONS'});return res.end();}
 if(parsed.pathname==='/api/health')return json(res,200,{ok:true,service:'Chami Live Studio backend'});
 if(parsed.pathname==='/api/ice'){
  const iceServers=[{urls:['stun:stun.l.google.com:19302']}];
  if(TURN_SECRET){
   const expiry=Math.floor(Date.now()/1000)+3600,username=`${expiry}:chami`;
   const credential=crypto.createHmac('sha1',TURN_SECRET).update(username).digest('base64');
   iceServers.push({urls:[`turn:${DOMAIN}:3478?transport=udp`,`turn:${DOMAIN}:3478?transport=tcp`],username,credential});
  }
  return json(res,200,{iceServers});
 }
 if(parsed.pathname.startsWith('/api/stream/')){
  if(!authorized(req))return json(res,401,{error:'Unauthorized. Check the private backend API token.'});
  let body='';req.on('data',c=>{body+=c;if(body.length>100000)req.destroy()});req.on('end',()=>{
   let data={};try{data=JSON.parse(body||'{}')}catch{return json(res,400,{error:'Invalid JSON'})}
   const room=cleanRoom(data.room);if(!room)return json(res,400,{error:'Invalid room'});
   if(parsed.pathname==='/api/stream/start'){
    if(!Array.isArray(data.destinations)||data.destinations.length<1||data.destinations.length>2)return json(res,400,{error:'Supply one or two RTMP destinations.'});
    if(broadcasts.has(room))return json(res,409,{error:'This room is already forwarding.'});
    const children=[];
    for(const dest of data.destinations){
     if(typeof dest!=='string'||!/^rtmps?:\/\//i.test(dest)||dest.length>1500)return json(res,400,{error:'Only RTMP/RTMPS destination URLs are accepted.'});
    }
    for(const dest of data.destinations){
     const args=['-hide_banner','-loglevel','warning','-rtsp_transport','tcp','-i',`rtsp://mediamtx:8554/${room}`,'-map','0:v:0','-map','0:a?','-c:v','libx264','-preset','veryfast','-tune','zerolatency','-b:v','3000k','-maxrate','3500k','-bufsize','6000k','-g','60','-pix_fmt','yuv420p','-c:a','aac','-b:a','128k','-ar','44100','-f','flv',dest];
     const child=spawn('ffmpeg',args,{stdio:['ignore','ignore','pipe']});
     let err='';child.stderr.on('data',d=>{err=(err+d.toString()).slice(-2000)});
     child.on('exit',(code)=>{if(code!==0)console.error(`FFmpeg exited (${code}) for room ${room}: ${err.replace(/(rtmps?:\/\/)[^\s]+/g,'[destination hidden]')}`)});
     children.push({child,started:Date.now()});
    }
    broadcasts.set(room,children);
    return json(res,200,{ok:true,message:'RTMP forwarding process started. Verify the platform preview before announcing the stream.'});
   }
   if(parsed.pathname==='/api/stream/stop'){
    const children=broadcasts.get(room)||[];for(const x of children)x.child.kill('SIGTERM');broadcasts.delete(room);
    return json(res,200,{ok:true,stopped:children.length});
   }
   if(parsed.pathname==='/api/stream/status')return json(res,200,{live:broadcasts.has(room)});
   return json(res,404,{error:'Unknown API endpoint'});
  });return;
 }
 json(res,404,{error:'Not found'});
});

const wss=new WebSocketServer({noServer:true});
server.on('upgrade',(req,socket,head)=>{
 const p=URL.parse(req.url,true);if(p.pathname!=='/ws'){socket.destroy();return}
 wss.handleUpgrade(req,socket,head,ws=>wss.emit('connection',ws,req));
});
wss.on('connection',(ws,req)=>{
 const p=URL.parse(req.url,true),room=cleanRoom(p.query.room),role=p.query.role==='studio'?'studio':'camera',name=String(p.query.name||role).slice(0,32);
 if(!room){ws.close(1008,'Room required');return}
 if(!rooms.has(room))rooms.set(room,new Map());
 const members=rooms.get(room);
 const cameras=[...members.values()].filter(x=>x.role==='camera').length;
 if(role==='camera'&&cameras>=10){send(ws,{type:'room-full'});ws.close();return}
 if(role==='studio'&&[...members.values()].some(x=>x.role==='studio')){send(ws,{type:'room-full'});ws.close();return}
 const id=crypto.randomUUID();const client={id,role,name,ws};members.set(id,client);
 send(ws,{type:'welcome',id,peers:[...members.values()].filter(x=>x.id!==id).map(({id,role,name})=>({id,role,name}))});
 for(const other of members.values()){
  if(other.id===id)continue;
  send(other.ws,{type:'peer-joined',peer:{id,role,name}});
  if(role==='studio'&&other.role==='camera')send(other.ws,{type:'studio-ready',id});
  if(role==='camera'&&other.role==='studio')send(ws,{type:'studio-ready',id:other.id});
 }
 ws.on('message',raw=>{
  let m;try{m=JSON.parse(raw.toString())}catch{return}
  if(m.type==='signal'&&m.to&&m.data){
   const target=members.get(String(m.to));if(target)send(target.ws,{type:'signal',from:id,data:m.data});
  }
  if(m.type==='disconnect-peer'&&m.to){const target=members.get(String(m.to));if(target)target.ws.close(4001,'Removed by studio');}
 });
 ws.on('close',()=>{
  members.delete(id);for(const other of members.values())send(other.ws,{type:'peer-left',id});
  if(!members.size)rooms.delete(room);
 });
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Chami studio signaling/API listening on ${PORT}`));
process.on('SIGTERM',()=>{for(const list of broadcasts.values())for(const x of list)x.child.kill('SIGTERM');server.close(()=>process.exit(0))});
