const $=id=>document.getElementById(id);
const state={backend:localStorage.backendUrl||'',media:localStorage.mediaUrl||'',role:null,room:'',name:'',id:null,ws:null,peers:new Map(),pcs:new Map(),streams:new Map(),videos:new Map(),gains:new Map(),audioCtx:null,mixDest:null,layout:'single',selected:null,programStream:null,recorder:null,recordChunks:[],whipPc:null,whipLocation:null,live:false,ticker:false,countdownUntil:0,muted:false};
const canvas=$('program'),ctx=canvas.getContext('2d');
function toast(s){$('toast').textContent=s;$('toast').classList.add('show');setTimeout(()=>$('toast').classList.remove('show'),2800)}
function setStatus(id,s,cls=''){const el=$(id);if(el){el.textContent=s;el.className=cls?`pill ${cls}`:'pill'}}
function normRoom(s){return s.trim().toLowerCase().replace(/[^a-z0-9_-]/g,'-').slice(0,32)}
function backend(){return state.backend.replace(/\/+$/,'')}
function media(){return (state.media||state.backend).replace(/\/+$/,'')}
function wsUrl(){return backend().replace(/^https:/,'wss:').replace(/^http:/,'ws:')+'/ws'}
function apiHeaders(){return {'Content-Type':'application/json','Authorization':'Bearer '+$('apiToken').value.trim()}}
function show(which){['setup','studio','camera'].forEach(x=>$(x).classList.toggle('hidden',x!==which))}
function saveSettings(){state.backend=$('backendUrl').value.trim();state.media=$('mediaUrl').value.trim()||state.backend;localStorage.backendUrl=state.backend;localStorage.mediaUrl=state.media;$('settingsDialog').close();toast('Settings saved')}
$('settingsBtn').onclick=()=>{$('backendUrl').value=state.backend;$('mediaUrl').value=state.media;$('settingsDialog').showModal()};
$('saveSettings').onclick=saveSettings;
function wsSend(obj){if(state.ws?.readyState===WebSocket.OPEN)state.ws.send(JSON.stringify(obj))}
function connectSignal(role,room,name){
 return new Promise((resolve,reject)=>{
  if(!state.backend) return reject(Error('Open Settings and enter your backend HTTPS address first.'));
  const u=new URL(wsUrl());u.searchParams.set('room',room);u.searchParams.set('role',role);u.searchParams.set('name',name);
  const ws=new WebSocket(u);state.ws=ws;
  const timer=setTimeout(()=>reject(Error('Signaling server did not respond.')),10000);
  ws.onopen=()=>{clearTimeout(timer);$('netState').textContent='CONNECTED';resolve()};
  ws.onerror=()=>{clearTimeout(timer);reject(Error('Could not reach the backend signaling server.'))};
  ws.onclose=()=>{$('netState').textContent='DISCONNECTED';if(state.role==='studio')$('roomStatus').textContent='Signaling connection lost.'};
  ws.onmessage=ev=>{let m;try{m=JSON.parse(ev.data)}catch{return}handleSignal(m)};
 });
}
async function iceConfig(){
 try{const r=await fetch(backend()+'/api/ice');if(!r.ok)throw Error();return (await r.json()).iceServers}
 catch{return [{urls:'stun:stun.l.google.com:19302'}]}
}
async function openStudio(){
 state.room=normRoom($('studioRoom').value);state.name=$('studioName').value.trim()||'Studio';if(!state.room)return toast('Enter a room name');
 try{state.role='studio';await connectSignal('studio',state.room,state.name);show('studio');$('roomLabel').textContent=' / '+state.room;$('roomStatus').textContent='Connected to signaling server. Waiting for phones.';setStatus('programState','STANDBY');startRender();toast('Studio opened. Connect camera phones using room: '+state.room)}
 catch(e){state.role=null;toast(e.message)}
}
$('openStudio').onclick=openStudio;
async function joinCamera(){
 state.room=normRoom($('cameraRoom').value);state.name=$('cameraName').value.trim()||'Camera';if(!state.room)return toast('Enter a room name');
 const mode=$('captureMode').value;
 try{
  if(!navigator.mediaDevices)throw Error('Media capture is unavailable. Open the HTTPS website in Chrome.');
  let stream;
  if(mode==='camera'){
   const h=Number($('cameraQuality').value),facing=$('cameraFacing').value;
   stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:facing},width:{ideal:h===1080?1920:h===720?1280:854},height:{ideal:h===1080?1080:h===720?720:480},frameRate:{ideal:30,max:30}},audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
  }else if(mode==='screen'){
   if(!navigator.mediaDevices.getDisplayMedia)throw Error('Screen sharing is not supported by this browser.');
   const display=await navigator.mediaDevices.getDisplayMedia({video:true,audio:false});
   const mic=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true}});
   stream=new MediaStream([...display.getVideoTracks(),...mic.getAudioTracks()]);
   display.getVideoTracks()[0].addEventListener('ended',leaveCamera);
  }else stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
  state.localStream=stream;$('localPreview').srcObject=stream;$('localPreview').classList.toggle('hidden',mode==='mic');$('audioOnly').classList.toggle('hidden',mode!=='mic');$('cameraTitle').textContent=state.name+' • '+mode;
  state.role='camera';await connectSignal('camera',state.room,state.name);show('camera');setStatus('cameraState','WAITING FOR STUDIO');
  state.ice=await iceConfig();
 }catch(e){state.localStream?.getTracks().forEach(t=>t.stop());state.localStream=null;state.role=null;toast('Could not connect source: '+e.message)}
}
$('joinCamera').onclick=joinCamera;
async function makeCameraOffer(studioId){
 if(!state.localStream||state.pcs.has(studioId))return;
 const pc=new RTCPeerConnection({iceServers:state.ice||await iceConfig()});state.pcs.set(studioId,pc);
 state.localStream.getTracks().forEach(t=>pc.addTrack(t,state.localStream));
 pc.onicecandidate=e=>{if(e.candidate)wsSend({type:'signal',to:studioId,data:{kind:'candidate',candidate:e.candidate}})};
 pc.onconnectionstatechange=()=>setStatus('cameraState',pc.connectionState.toUpperCase(),pc.connectionState==='connected'?'live':'bad');
 const offer=await pc.createOffer();await pc.setLocalDescription(offer);wsSend({type:'signal',to:studioId,data:{kind:'offer',sdp:pc.localDescription}});
}
async function handleSignal(m){
 if(m.type==='welcome'){
  state.id=m.id;
  if(state.role==='studio'){for(const p of m.peers||[])if(p.role==='camera')state.peers.set(p.id,p);renderSources()}
  if(state.role==='camera'){const studio=(m.peers||[]).find(p=>p.role==='studio');if(studio)makeCameraOffer(studio.id)}
 }
 if(m.type==='peer-joined'){
  if(state.role==='studio'&&m.peer.role==='camera'){state.peers.set(m.peer.id,m.peer);renderSources()}
  if(state.role==='camera'&&m.peer.role==='studio')makeCameraOffer(m.peer.id);
 }
 if(m.type==='studio-ready'&&state.role==='camera')makeCameraOffer(m.id);
 if(m.type==='peer-left'){
  state.peers.delete(m.id);state.pcs.get(m.id)?.close();state.pcs.delete(m.id);if(state.role==='studio')removeSource(m.id);renderSources();
 }
 if(m.type==='signal'&&state.role==='studio')await receiveStudioSignal(m.from,m.data);
 if(m.type==='signal'&&state.role==='camera')await receiveCameraSignal(m.from,m.data);
 if(m.type==='room-full')toast('This room already has 10 camera sources.');
}
async function receiveCameraSignal(from,d){
 const pc=state.pcs.get(from);if(!pc)return;
 if(d.kind==='answer')await pc.setRemoteDescription(d.sdp);
 if(d.kind==='candidate')try{await pc.addIceCandidate(d.candidate)}catch{}
}
async function receiveStudioSignal(from,d){
 let pc=state.pcs.get(from);
 if(d.kind==='offer'){
  if(pc)pc.close();pc=new RTCPeerConnection({iceServers:await iceConfig()});state.pcs.set(from,pc);
  pc.onicecandidate=e=>{if(e.candidate)wsSend({type:'signal',to:from,data:{kind:'candidate',candidate:e.candidate}})};
  pc.ontrack=e=>{const stream=e.streams[0]||new MediaStream([e.track]);addSource(from,stream,state.peers.get(from)?.name||'Camera')};
  pc.onconnectionstatechange=()=>{if(pc.connectionState==='failed'||pc.connectionState==='closed')removeSource(from)};
  await pc.setRemoteDescription(d.sdp);const answer=await pc.createAnswer();await pc.setLocalDescription(answer);wsSend({type:'signal',to:from,data:{kind:'answer',sdp:pc.localDescription}});
 }else if(d.kind==='candidate'&&pc)try{await pc.addIceCandidate(d.candidate)}catch{}
}
function addSource(id,stream,name){
 if(state.streams.has(id))return;
 state.streams.set(id,stream);
 const v=document.createElement('video');v.autoplay=true;v.playsInline=true;v.muted=true;v.srcObject=stream;v.className='hidden';document.body.append(v);state.videos.set(id,v);
 if(!state.audioCtx){state.audioCtx=new AudioContext();state.mixDest=state.audioCtx.createMediaStreamDestination()}
 const tracks=stream.getAudioTracks();
 if(tracks.length){const node=state.audioCtx.createMediaStreamSource(new MediaStream(tracks));const gain=state.audioCtx.createGain();gain.gain.value=1;node.connect(gain).connect(state.mixDest);state.gains.set(id,{gain,name})}
 if(!state.selected)state.selected=id;
 renderSources();toast(name+' connected');
}
function removeSource(id){
 state.streams.delete(id);state.videos.get(id)?.remove();state.videos.delete(id);state.gains.get(id)?.gain.disconnect();state.gains.delete(id);if(state.selected===id)state.selected=state.streams.keys().next().value||null;renderSources();
}
function renderSources(){
 $('sourceCount').textContent=state.streams.size+' / 10';$('sourceList').innerHTML='';$('sourceButtons').innerHTML='';
 if(!state.streams.size){$('sourceList').innerHTML='<div class="empty">No sources connected</div>';$('sourceButtons').innerHTML='<div class="empty">Waiting for camera phones…</div>'}
 for(const [id,stream] of state.streams){
  const name=state.peers.get(id)?.name||'Camera';
  const item=document.createElement('div');item.className='sourceItem';item.innerHTML=`<b></b><small>${stream.getVideoTracks().length?'VIDEO':'AUDIO ONLY'} • CONNECTED</small><button class="ghost">Remove</button>`;item.querySelector('b').textContent=name;item.querySelector('button').onclick=()=>{state.pcs.get(id)?.close();wsSend({type:'disconnect-peer',to:id});removeSource(id)};$('sourceList').append(item);
  const b=document.createElement('button');b.textContent=name;b.className=state.selected===id?'selected':'';b.onclick=()=>{state.selected=id;renderSources()};$('sourceButtons').append(b);
 }
 $('audioMixer').innerHTML='';
 if(!state.gains.size)$('audioMixer').innerHTML='<div class="empty">No audio tracks received</div>';
 for(const [id,obj] of state.gains){const row=document.createElement('div');row.className='audioItem';row.innerHTML='<div class="row"><b></b><button class="ghost">Mute</button></div><input type="range" min="0" max="1.5" step=".01" value="1">';row.querySelector('b').textContent=obj.name;row.querySelector('button').onclick=()=>{obj.gain.gain.value=obj.gain.gain.value?0:1;row.querySelector('button').textContent=obj.gain.gain.value?'Mute':'Unmute'};row.querySelector('input').oninput=e=>obj.gain.gain.value=Number(e.target.value);$('audioMixer').append(row)}
}
function renderSourcesFromPeers(){renderSources()}
function drawVideo(id,x,y,w,h){
 const v=state.videos.get(id);if(!v||v.readyState<2)return;
 const vw=v.videoWidth||16,vh=v.videoHeight||9;const scale=Math.max(w/vw,h/vh),sw=w/scale,sh=h/scale,sx=(vw-sw)/2,sy=(vh-sh)/2;
 ctx.drawImage(v,sx,sy,sw,sh,x,y,w,h);
}
function renderFrame(){
 ctx.fillStyle='#05080d';ctx.fillRect(0,0,1280,720);
 const ids=[...state.streams.keys()];
 if(ids.length){
  if(state.layout==='single')drawVideo(state.selected||ids[0],0,0,1280,720);
  else if(state.layout==='pip'){drawVideo(state.selected||ids[0],0,0,1280,720);const other=ids.find(x=>x!==state.selected);if(other){ctx.fillStyle='#000';ctx.fillRect(930,30,320,190);drawVideo(other,940,40,300,170);ctx.strokeStyle='#fff';ctx.lineWidth=3;ctx.strokeRect(940,40,300,170)}}
  else if(state.layout==='split'){drawVideo(ids[0],0,0,640,720);if(ids[1])drawVideo(ids[1],640,0,640,720);else drawVideo(ids[0],640,0,640,720);ctx.fillStyle='#fff';ctx.fillRect(637,0,6,720)}
  else {for(let i=0;i<4;i++){const x=(i%2)*640,y=Math.floor(i/2)*360,id=ids[i];if(id)drawVideo(id,x,y,640,360);else{ctx.fillStyle='#111d2c';ctx.fillRect(x,y,640,360)}}}
 }else{ctx.fillStyle='#9bb0c6';ctx.font='28px system-ui';ctx.textAlign='center';ctx.fillText('WAITING FOR CAMERA SOURCES',640,365)}
 if($('lowerEnabled').checked&&$('lowerTitle').value){ctx.fillStyle='#071321dd';ctx.fillRect(35,570,650,105);ctx.fillStyle='#36d8e8';ctx.fillRect(35,570,7,105);ctx.fillStyle='#fff';ctx.textAlign='left';ctx.font='bold 32px system-ui';ctx.fillText($('lowerTitle').value,60,615);ctx.fillStyle='#b7cadb';ctx.font='20px system-ui';ctx.fillText($('lowerSub').value,60,650)}
 if($('bugText').value){ctx.fillStyle='#071321cc';ctx.fillRect(1030,30,220,48);ctx.fillStyle='#fff';ctx.font='bold 20px system-ui';ctx.textAlign='center';ctx.fillText($('bugText').value.slice(0,20),1140,61)}
 if(state.ticker&&$('tickerText').value){ctx.fillStyle='#071321ee';ctx.fillRect(0,680,1280,40);ctx.fillStyle='#36d8e8';ctx.font='bold 19px system-ui';ctx.textAlign='left';ctx.fillText($('tickerText').value,22,707)}
 if(state.countdownUntil>Date.now()){const n=Math.ceil((state.countdownUntil-Date.now())/1000);ctx.fillStyle='#0009';ctx.fillRect(0,0,1280,720);ctx.fillStyle='#fff';ctx.textAlign='center';ctx.font='bold 160px system-ui';ctx.fillText(String(n),640,405)}
 requestAnimationFrame(renderFrame);
}
function startRender(){if(state.rendering)return;state.rendering=true;renderFrame()}
document.querySelectorAll('[data-layout]').forEach(b=>b.onclick=()=>{state.layout=b.dataset.layout;document.querySelectorAll('.layout').forEach(x=>x.classList.toggle('active',x===b))});
$('takeBtn').onclick=()=>{if(!state.selected)return toast('Connect a camera first');state.audioCtx?.resume();toast('Program source changed')};
$('muteAll').onclick=()=>{state.muted=!state.muted;for(const x of state.gains.values())x.gain.gain.value=state.muted?0:1;$('muteAll').textContent=state.muted?'Unmute all':'Mute all'};
$('lowerEnabled').onchange=()=>{};$('tickerToggle').onclick=()=>state.ticker=!state.ticker;$('countdown').onclick=()=>state.countdownUntil=Date.now()+10000;
$('snapshot').onclick=()=>canvas.toBlob(b=>downloadBlob(b,'program-snapshot.png'));
$('fullScreen').onclick=()=>canvas.requestFullscreen?.();
function downloadBlob(blob,name){const a=document.createElement('a'),u=URL.createObjectURL(blob);a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),3000)}
$('recordStart').onclick=async()=>{
 try{state.audioCtx?.resume();const tracks=canvas.captureStream(30).getVideoTracks();if(state.mixDest)tracks.push(...state.mixDest.stream.getAudioTracks());state.programStream=new MediaStream(tracks);
  const mime=['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm'].find(x=>MediaRecorder.isTypeSupported(x));state.recorder=new MediaRecorder(state.programStream,mime?{mimeType:mime,videoBitsPerSecond:5000000}:undefined);state.recordChunks=[];state.recorder.ondataavailable=e=>{if(e.data.size)state.recordChunks.push(e.data)};state.recorder.onstop=()=>downloadBlob(new Blob(state.recordChunks,{type:state.recorder.mimeType||'video/webm'}),'chami-live-'+Date.now()+'.webm');state.recorder.start(1000);$('recordStart').disabled=true;$('recordStop').disabled=false;setStatus('recordState','RECORDING','live')
 }catch(e){toast('Recording failed: '+e.message)}
};
$('recordStop').onclick=()=>{state.recorder?.stop();$('recordStart').disabled=false;$('recordStop').disabled=true;setStatus('recordState','SAVED')}
async function publishWHIP(){
 const pc=new RTCPeerConnection({iceServers:await iceConfig()});state.whipPc=pc;
 const out=state.programStream||new MediaStream([...canvas.captureStream(30).getTracks(),...(state.mixDest?.stream.getAudioTracks()||[])]);
 out.getTracks().forEach(t=>pc.addTrack(t,out));
 const offer=await pc.createOffer();await pc.setLocalDescription(offer);
 await new Promise((resolve,reject)=>{if(pc.iceGatheringState==='complete')return resolve();const timer=setTimeout(()=>reject(Error('ICE gathering timed out')),12000);pc.onicegatheringstatechange=()=>{if(pc.iceGatheringState==='complete'){clearTimeout(timer);resolve()}}});
 const url=media()+'/'+encodeURIComponent(state.room)+'/whip';
 const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/sdp'},body:pc.localDescription.sdp});
 if(!response.ok)throw Error('Media server rejected WHIP publish: '+response.status+' '+(await response.text()).slice(0,180));
 const answer=await response.text();state.whipLocation=response.headers.get('Location');await pc.setRemoteDescription({type:'answer',sdp:answer});
}

$('streamPlatform').onchange=()=>{
 const p=$('streamPlatform').value;
 if(p==='youtube')$('rtmpUrl').value='rtmps://a.rtmps.youtube.com/live2';
 else if(p==='facebook')$('rtmpUrl').value='rtmps://live-api-s.facebook.com:443/rtmp/';
 else $('rtmpUrl').value='';
};

$('streamStart').onclick=async()=>{
 const url=$('rtmpUrl').value.trim(),key=$('streamKey').value.trim(),token=$('apiToken').value.trim();
 if(!state.streams.size)return toast('Connect at least one source first');
 if(!url.startsWith('rtmp://')&&!url.startsWith('rtmps://'))return toast('Enter a valid RTMP or RTMPS server URL');
 if(!key||!token)return toast('Enter your stream key and private backend API token');
 $('streamStart').disabled=true;$('streamStatus').textContent='Connecting program output to media server…';
 try{
  await publishWHIP();
  await new Promise(r=>setTimeout(r,1600));
  const r=await fetch(backend()+'/api/stream/start',{method:'POST',headers:apiHeaders(),body:JSON.stringify({room:state.room,destinations:[url.replace(/\/+$/,'')+'/'+key]})});
  const data=await r.json();if(!r.ok)throw Error(data.error||'Backend could not start RTMP forwarding');
  state.live=true;$('streamStop').disabled=false;setStatus('programState','LIVE','live');$('streamStatus').textContent='LIVE • RTMP output started. Check the platform preview.';
 }catch(e){$('streamStatus').textContent='Live start failed: '+e.message;state.whipPc?.close();state.whipPc=null;$('streamStart').disabled=false}
};
$('streamStop').onclick=async()=>{
 try{await fetch(backend()+'/api/stream/stop',{method:'POST',headers:apiHeaders(),body:JSON.stringify({room:state.room})})}catch{}
 try{if(state.whipLocation)await fetch(new URL(state.whipLocation,media()).href,{method:'DELETE'});else await fetch(media()+'/'+encodeURIComponent(state.room)+'/whip',{method:'DELETE'})}catch{}
 state.whipPc?.close();state.whipPc=null;state.live=false;$('streamStop').disabled=true;$('streamStart').disabled=false;setStatus('programState','STANDBY');$('streamStatus').textContent='Stream stopped.';
};
$('copyRoom').onclick=()=>navigator.clipboard?.writeText(state.room).then(()=>toast('Room name copied'));
$('leaveRoom').onclick=()=>location.reload();
$('endStudio').onclick=()=>{if(state.live)$('streamStop').click();state.ws?.close();for(const pc of state.pcs.values())pc.close();for(const id of [...state.streams.keys()])removeSource(id);show('setup');state.role=null};
$('flipCamera').onclick=async()=>{const track=state.localStream?.getVideoTracks()[0];if(!track)return;const next=track.getSettings().facingMode==='user'?'environment':'user';try{const s=await navigator.mediaDevices.getUserMedia({video:{facingMode:{exact:next}},audio:false});const nt=s.getVideoTracks()[0];const sender=[...state.pcs.values()][0]?.getSenders().find(x=>x.track?.kind==='video');if(sender)await sender.replaceTrack(nt);track.stop();state.localStream.removeTrack(track);state.localStream.addTrack(nt);$('localPreview').srcObject=state.localStream}catch(e){toast('Could not switch camera: '+e.message)}};
$('torch').onclick=async()=>{const t=state.localStream?.getVideoTracks()[0];if(!t)return;try{const on=!t.getSettings().torch;await t.applyConstraints({advanced:[{torch:on}]});toast('Torch '+(on?'on':'off'))}catch{toast('Torch is not supported on this phone/browser')}};
function leaveCamera(){state.ws?.close();for(const pc of state.pcs.values())pc.close();state.localStream?.getTracks().forEach(t=>t.stop());state.localStream=null;state.role=null;show('setup')}
$('leaveCamera').onclick=leaveCamera;
window.addEventListener('beforeunload',()=>{state.ws?.close();state.localStream?.getTracks().forEach(t=>t.stop());state.whipPc?.close()});
if(state.backend){$('backendUrl').value=state.backend;$('mediaUrl').value=state.media}
